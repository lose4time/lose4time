 var clicks = 0; // change int to var here
    function countClicks(path) {
        clicks += 0.5;
        document.getElementById("clicks").innerHTML = clicks;
         var audio = new Audio(); // Создаём новый элемент Audio
  audio.src = 'ebu.mp3'; // Указываем путь к звуку "клика"
  audio.autoplay = true; // Автоматически запускаем
         let image = document.getElementById('image');
      image.src = path;
    };




function soundClick() {
    if (clicks>=20) {
  var audio = new Audio(); // Создаём новый элемент Audio
  audio.src = 'ston.mp3'; // Указываем путь к звуку "клика"
  audio.autoplay = true; // Автоматически запускаем
        clicks-=20;
        document.getElementById("clicks").innerHTML = clicks;
    }
    else {
         var audio = new Audio(); // Создаём новый элемент Audio
  audio.src = 'false.mp3'; // Указываем путь к звуку "клика"
  audio.autoplay = true; // Автоматически запускаем
        alert('Долбаеб, посмотри, сколько у тебя')
    }
}



let animation = anime({
  targets: '.letter',
  opacity: 1,
  translateY: 50, 
  rotate: {
    value: 360,
    duration: 2000,
    easing: 'easeInExpo'
  }, 
  scale: anime.stagger([0.7, 1], {from: 'center'}), 
  delay: anime.stagger(100, {start: 1000}), 
 
});        


